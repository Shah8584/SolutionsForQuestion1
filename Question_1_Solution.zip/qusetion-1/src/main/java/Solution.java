import java.util.List;
import java.util.Map;
import java.util.HashMap;

class Solution {

    /*
     * Complete the 'numberOfTokens' function below.
     *
     * The function is expected to return an INTEGER.
     * The function accepts following parameters:
     *  1. INTEGER expiryLimit
     *  2. 2D_INTEGER_ARRAY commands
     */

    public static int numberOfTokens(int expiryLimit, List<List<Integer>> commands) {
        Map<Integer, Integer> tokenExpiryMap = new HashMap<>();
        int maxTime = 0;

        for (List<Integer> cmd : commands) {
            int type = cmd.get(0);
            int tokenId = cmd.get(1);
            int time = cmd.get(2);

            // Track max time to check active tokens at the end
            if (time > maxTime) {
                maxTime = time;
            }

            if (type == 0) {
                // Create token with expiry = time + expiryLimit
                tokenExpiryMap.put(tokenId, time + expiryLimit);
            } else if (type == 1) {
                // Reset token expiry if token exists and is still valid at 'time'
                if (tokenExpiryMap.containsKey(tokenId)) {
                    int currentExpiry = tokenExpiryMap.get(tokenId);
                    if (time <= currentExpiry) {
                        tokenExpiryMap.put(tokenId, time + expiryLimit);
                    }
                    // else ignore reset for expired token
                }
                // else ignore reset for non-existent token
            }
        }

        // Count tokens that have expiry time > maxTime (still active)
        int activeTokens = 0;
        for (int expiry : tokenExpiryMap.values()) {
            if (expiry > maxTime) {
                activeTokens++;
            }
        }

        return activeTokens;
    }
}
