package com.example.product_service.service;

import com.example.product_service.entity.Product;
import com.example.product_service.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public Page<Product> listProducts(String productCode, Pageable pageable) {
        if (productCode == null || productCode.isBlank()) {
            return productRepository.findAll(pageable);
        }
        return productRepository.findByProductCodeContainingIgnoreCase(productCode, pageable);
    }
}
