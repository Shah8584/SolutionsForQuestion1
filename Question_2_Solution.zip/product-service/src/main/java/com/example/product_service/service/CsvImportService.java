package com.example.product_service.service;

import com.example.product_service.entity.Category;
import com.example.product_service.entity.Product;
import com.example.product_service.repository.CategoryRepository;
import com.example.product_service.repository.ProductRepository;
import com.opencsv.CSVReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.FileReader;
import java.time.LocalDateTime;

@Service
public class CsvImportService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    @Value("${csv.file.path}")
    private String csvFilePath;

    public CsvImportService(ProductRepository productRepository, CategoryRepository categoryRepository) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
    }

    public void importCsv() throws Exception {
        try (CSVReader reader = new CSVReader(new FileReader(csvFilePath))) {
            String[] line;
            reader.readNext(); // Skip header

            while ((line = reader.readNext()) != null) {
                String productCode = line[0].trim();
                String productName = line[1].trim();
                String productCategoryCode = line[2].trim(); // not used directly
                String categoryCode = line[3].trim();
                String categoryName = line[4].trim();

                // Check if category exists, else create
                Category category = categoryRepository.findById(categoryCode)
                        .orElseGet(() -> {
                            Category newCat = new Category(categoryCode, categoryName, LocalDateTime.now());
                            return categoryRepository.save(newCat);
                        });

                // Check if product already exists
                if (!productRepository.existsById(productCode)) {
                    Product product = new Product(
                            productCode,
                            productName,
                            productCategoryCode,
                            LocalDateTime.now(),
                            category
                    );
                    productRepository.save(product);
                }
            }

            System.out.println("CSV import completed.");
        }
    }
}
