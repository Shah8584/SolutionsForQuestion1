package com.example.product_service.controller;

import com.example.product_service.entity.Category;
import com.example.product_service.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @GetMapping
    public ResponseEntity<Page<Category>> getCategories(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "creation_date,desc") String sort
    ) {
        Sort.Order order = parseSort(sort);
        Pageable pageable = PageRequest.of(page, size, Sort.by(order));
        Page<Category> result = categoryService.listCategories(pageable);
        return ResponseEntity.ok(result);
    }

    private Sort.Order parseSort(String sort) {
        String[] parts = sort.split(",", 2);
        String field = parts[0];
        Sort.Direction dir = (parts.length > 1 && parts[1].equalsIgnoreCase("asc")) ?
                Sort.Direction.ASC : Sort.Direction.DESC;
        return new Sort.Order(dir, field);
    }
}
