package com.example.product_service.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "products")
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class Product {

    @Id
    @Column(name = "product_code")
    private String productCode;

    @Column(name = "product_name")
    private String productName;

    // read-only view of the FK column (maps to same column used by @JoinColumn)
    @Column(name = "category_code", insertable = false, updatable = false)
    private String productCategoryCode;

    @Column(name = "creation_date")
    private LocalDateTime creationDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_code", referencedColumnName = "category_code")
    private Category category;

    // Constructors
    public Product() {}

    public Product(String productCode, String productName, String productCategoryCode, LocalDateTime creationDate, Category category) {
        this.productCode = productCode;
        this.productName = productName;
        this.productCategoryCode = productCategoryCode;
        this.creationDate = creationDate;
        this.category = category;
    }

    // Getters and Setters
    public String getProductCode() { return productCode; }
    public void setProductCode(String productCode) { this.productCode = productCode; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public String getProductCategoryCode() { return productCategoryCode; }
    public void setProductCategoryCode(String productCategoryCode) { this.productCategoryCode = productCategoryCode; }

    public LocalDateTime getCreationDate() { return creationDate; }
    public void setCreationDate(LocalDateTime creationDate) { this.creationDate = creationDate; }

    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }
}
